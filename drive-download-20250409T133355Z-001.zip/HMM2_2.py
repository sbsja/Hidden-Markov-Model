import numpy as np  # Import the NumPy library for numerical computations

def viterbi_algorithm_help(transition_matrix, emission_matrix, initial_probabilities, observations):
    """
    Helper function to initialize the Viterbi algorithm.
    
    Parameters:
    - transition_matrix: 2D list representing state transition probabilities.
    - emission_matrix: 2D list representing observation likelihoods given states.
    - initial_probabilities: List of initial state probabilities.
    - observations: List of observed emissions.

    Returns:
    - The most likely sequence of hidden states.
    """
    T = len(observations)  # Number of time steps (length of observation sequence)
    N = len(initial_probabilities)  # Number of possible hidden states

    # Initialize delta (probability of most likely path to each state at time t)
    delta = np.zeros((T, N))  

    # Initialize delta_idx (stores the most probable previous state for backtracking)
    delta_idx = np.zeros((T, N), dtype=int)  

    # Call the main Viterbi algorithm function
    return viterbi_algorithm(delta, delta_idx, transition_matrix, emission_matrix, observations)


def viterbi_algorithm(delta, delta_idx, transition_matrix, emission_matrix, observations):
    """
    Implements the Viterbi algorithm to find the most likely sequence of hidden states.
    
    Parameters:
    - delta: 2D NumPy array to store probabilities of most likely sequences.
    - delta_idx: 2D NumPy array to store backtracking indices.
    - transition_matrix: 2D list representing state transition probabilities.
    - emission_matrix: 2D list representing observation likelihoods given states.
    - observations: List of observed emissions.

    Returns:
    - A list representing the most likely sequence of hidden states.
    """
    T, N = delta.shape  # Extract time steps (T) and number of states (N)

    # Fill in delta and delta_idx matrices
    for t in range(1, T):
        for i in range(N):
            # Compute probabilities of reaching state i from all previous states
            max_prob = delta[t-1] * np.array([row[i] for row in transition_matrix])
            # Store the maximum probability for state i at time t
            delta[t, i] = np.max(max_prob) * emission_matrix[i][observations[t]]
            # Store the previous state that led to this maximum probability
            delta_idx[t, i] = np.argmax(max_prob)

    print(delta)
    print(delta_idx)

    # Backtracking step: Retrieve the most probable sequence of states
    states = np.zeros(T, dtype=int)  # Array to store the most likely state sequence
    states[-1] = np.argmax(delta[-1])  # Start with the most probable final state

    # Trace back through the delta_idx matrix to reconstruct the path
    for t in range(T-2, -1, -1):
        states[t] = delta_idx[t+1, states[t+1]]

    return states  # Return the most likely state sequence


def read_matrix():
    """
    Reads a matrix from standard input.
    
    Expected input format:
    - First line: two integers indicating the number of rows and columns.
    - Subsequent values: row-wise elements of the matrix.
    
    Returns:
    - A 2D list representing the input matrix.
    """
    line = input().strip().split()  # Read input and split into tokens
    rows, cols = int(line[0]), int(line[1])  # Extract matrix dimensions
    elements = list(map(float, line[2:]))  # Convert remaining input to floats
    matrix = [elements[i * cols:(i + 1) * cols] for i in range(rows)]  # Reshape into 2D list
    return matrix  # Return the matrix


if __name__ == "__main__":
    """
    Main execution block.
    - Reads transition, emission, and initial probability matrices from input.
    - Reads observation sequence.
    - Calls the Viterbi algorithm to compute the most likely state sequence.
    - Prints the resulting state sequence.
    """
    # Read the transition matrix (A), emission matrix (B), and initial probability vector (pi)
    A = read_matrix()  # Transition probability matrix
    B = read_matrix()  # Emission probability matrix
    pi = read_matrix()[0]  # Initial probability vector (assumed to be a single row)

    # Read the sequence of observations
    emissions_input = input().strip().split()
    T = int(emissions_input[0])  # Number of time steps
    emissions = list(map(int, emissions_input[1:]))  # Convert observations to integers

    # Run the Viterbi algorithm to determine the most likely sequence of hidden states
    result = viterbi_algorithm_help(A, B, pi, emissions)
    
    # Print the resulting sequence of hidden states
    print(" ".join(map(str, result)))
